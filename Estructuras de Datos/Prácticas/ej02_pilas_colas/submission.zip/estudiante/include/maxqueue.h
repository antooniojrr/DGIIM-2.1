/**
 * @file maxqueue.h
 * @brief  Archivo de especificación del TDA MaxQueue
 * @author
 */

#ifndef _MAXQUEUE_H_
#define _MAXQUEUE_H_

#include <stack>
#include <iostream>

using namespace std;

struct element {
    int value; // Current value to store
    int maximum; // Current max value in the structure

};

class MaxQueue{

private:

     stack<element> _data;

public:

    MaxQueue();

    void push(int n);

    //  void push(element n);

    void pop();

    element front() const;

    bool empty() const;

    int size() const;

};

ostream& operator<< (ostream& flujo, const element& p);

#endif // _MAXQUEUE_H_
